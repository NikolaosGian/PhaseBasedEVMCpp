#include <iostream>
#include <vector>
#include <string>
#include <cstdint>
#include <tuple>
#include <cassert>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <valarray>
#include <complex> 




extern "C" {
#include <libavutil/imgutils.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
}


void readFramesFromAvi(const std::string& filePath, std::vector<std::vector<std::vector<uint8_t>>>& vid,
                       int& width, int& height, int& numberOfFrames, int& numberOfChannels,
                       double &fps,
                       AVPixelFormat& pixelFormat) {
                       
                       
    AVFormatContext* formatContext = nullptr;
    AVCodec* codec = nullptr;
    AVCodecContext* codecContext = nullptr;
    AVPacket packet;
    AVFrame* frame = nullptr;
    SwsContext* swsContext = nullptr;

    av_register_all();
    avcodec_register_all();

    if (avformat_open_input(&formatContext, filePath.c_str(), nullptr, nullptr) != 0) {
        std::cerr << "Error opening file: " << filePath << std::endl;
        return;
    }

    if (avformat_find_stream_info(formatContext, nullptr) < 0) {
        std::cerr << "Error finding stream information." << std::endl;
        avformat_close_input(&formatContext);
        return;
    }

    // Find the video stream
    int videoStreamIndex = -1;
    for (unsigned int i = 0; i < formatContext->nb_streams; ++i) {
        if (formatContext->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            videoStreamIndex = i;
            break;
        }
    }

    if (videoStreamIndex == -1) {
        std::cerr << "Error finding video stream." << std::endl;
        avformat_close_input(&formatContext);
        return;
    }

    // Retrieve the FPS from the stream
    AVStream* videoStream = formatContext->streams[videoStreamIndex];
    if (videoStream->avg_frame_rate.num && videoStream->avg_frame_rate.den) {
        fps = av_q2d(videoStream->avg_frame_rate);
    } else if (videoStream->r_frame_rate.num && videoStream->r_frame_rate.den) {
        fps = av_q2d(videoStream->r_frame_rate);
    } else {
        std::cerr << "Error retrieving FPS information." << std::endl;
        avformat_close_input(&formatContext);
        return;
    }
	
    codecContext = avcodec_alloc_context3(nullptr);
    if (!codecContext) {
        std::cerr << "Error allocating codec context." << std::endl;
        avformat_close_input(&formatContext);
        return;
    }

    avcodec_parameters_to_context(codecContext, formatContext->streams[videoStreamIndex]->codecpar);

    codec = avcodec_find_decoder(codecContext->codec_id);
    if (!codec) {
        std::cerr << "Error finding codec." << std::endl;
        avcodec_free_context(&codecContext);
        avformat_close_input(&formatContext);
        return;
    }

    if (avcodec_open2(codecContext, codec, nullptr) < 0) {
        std::cerr << "Error opening codec." << std::endl;
        avcodec_free_context(&codecContext);
        avformat_close_input(&formatContext);
        return;
    }

    frame = av_frame_alloc();
    if (!frame) {
        std::cerr << "Error allocating frame." << std::endl;
        avcodec_free_context(&codecContext);
        avformat_close_input(&formatContext);
        return;
    }

    // Initialize packet for reading video frames
    av_init_packet(&packet);

    int response = 0;
    
    // Read frames
    while (av_read_frame(formatContext, &packet) >= 0) {
        if (packet.stream_index == videoStreamIndex) {
            response = avcodec_send_packet(codecContext, &packet);
            if (response < 0) {
                std::cerr << "Error sending a packet for decoding." << std::endl;
                break;
            }

            while (response >= 0) {
                response = avcodec_receive_frame(codecContext, frame);
                if (response == AVERROR(EAGAIN) || response == AVERROR_EOF)
                    break;
                else if (response < 0) {
                    std::cerr << "Error during decoding." << std::endl;
                    break;
                }

                // Convert the image from its native format to RGB
                if (!swsContext) {
                    swsContext = sws_getContext(codecContext->width, codecContext->height,
                                                codecContext->pix_fmt, codecContext->width,
                                                codecContext->height, AV_PIX_FMT_RGB24,
                                                SWS_BILINEAR, nullptr, nullptr, nullptr);
                    if (!swsContext) {
                        std::cerr << "Error creating sws context." << std::endl;
                        break;
                    }
                }

                width = codecContext->width;
                height = codecContext->height;
                numberOfChannels = av_get_channel_layout_nb_channels(codecContext->channel_layout);
                pixelFormat = codecContext->pix_fmt;

                // Allocate memory for the frame data
               // std::vector<uint8_t> frameData(width * height * 3);
               
               std::vector<std::vector<uint8_t>> frameData(height, std::vector<uint8_t>(width * 3, 0));
               
               // Create a 1D vector for sws_scale
		std::vector<uint8_t> frameData1D(width * height * 3);

                uint8_t* destSlice[1] = {frameData1D.data()};
                int destStride[1] = {3 * width};

                sws_scale(swsContext, frame->data, frame->linesize, 0, codecContext->height,
                          destSlice, destStride);

		// Copy data from the 1D vector to the 2D vector
		for (size_t i = 0; i < height; ++i) {
    			std::copy(frameData1D.begin() + i * 3 * width, frameData1D.begin() + (i + 1) * 3 * width, frameData[i].begin());
		}
                // Add the frame data to the vid vector
                vid.push_back(frameData);
            }
        }

        av_packet_unref(&packet);
    }

    
    avcodec_free_context(&codecContext);
    av_frame_free(&frame);
    avformat_close_input(&formatContext);
    sws_freeContext(swsContext);

    // Set the number of frames
    numberOfFrames = static_cast<int>(vid.size());
}

void freeFrames(std::vector<AVFrame*>& frames) {
    for (AVFrame* frame : frames) {
        av_freep(&frame->data[0]);
        av_frame_free(&frame);
    }
    
}

// Function to run FFmpeg command
int runFFmpegCommand(const char* framePath, const std::string& outputFilename) {
    // Construct the FFmpeg command
    const char* ffmpegCommand = "ffmpeg -framerate 30 -i %s/frame%%d.ppm -vf \"scale=iw*2:ih*2\" -c:v libx264 -crf 20 -pix_fmt yuv420p %s";

    // Allocate memory for the command string
    size_t commandSize = strlen(ffmpegCommand) + strlen(framePath) + outputFilename.length() + 10;  // Additional space for paths
    char* fullCommand = new char[commandSize];

    // Format the command string with input and output paths
    snprintf(fullCommand, commandSize, ffmpegCommand, framePath, outputFilename.c_str());

    // Execute the FFmpeg command
    int result = std::system(fullCommand);

    // Clean up allocated memory
    delete[] fullCommand;

    // Return the result of the system command
    return result;
}



void exportFrames(const std::vector<std::vector<std::vector<uint8_t>>>& vid, int width, int height) {
    for (size_t i = 0; i < vid.size(); ++i) {
        const std::vector<std::vector<uint8_t>>& frameData = vid[i];

        // Create a filename for the image (you can customize the filename as needed)
        std::string filename = "data/pics/frame" + std::to_string(i) + ".ppm";

        // Write PPM header
        std::ofstream file(filename, std::ios::out | std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Error opening file for writing: " << filename << std::endl;
            continue;  // Move on to the next frame
        }

        file << "P6\n" << width << " " << height << "\n255\n";

        // Write RGB data
        for (const auto& row : frameData) {
            file.write(reinterpret_cast<const char*>(row.data()), row.size());
        }

        file.close();

        std::cout << "Frame " << i << " exported as " << filename << std::endl;
    }
}


//--------------------Function for Matrix and other stuff----------------------------------------

int factorial(int n){

     return (n==0) || (n==1) ? 1 : n* factorial(n-1);
}


template <typename T>
std::vector<std::vector<T>> createZerosMatrix(int rows, int cols) {
    return std::vector<std::vector<T>>(rows, std::vector<T>(cols, T(0)));
}

// Function to calculate maxSCFpyrHt
template <typename T>
int maxSCFpyrHt(const std::vector<std::vector<T>>& im) {
    int minHeight = std::min(im.size(), im[0].size());
    int maxHeight = static_cast<int>(std::floor(std::log2(minHeight))) - 2;
    return maxHeight;
}

// Templated function to perform element-wise multiplication of two matrices
template <typename T>
std::vector<std::vector<T>> elementWiseMultiply(const std::vector<std::vector<T>>& matrix1, const std::vector<std::vector<T>>& matrix2) {
    // Check if the matrices have the same dimensions
    if (matrix1.size() != matrix2.size() || matrix1[0].size() != matrix2[0].size()) {
        std::cerr << "Error: Matrices must have the same dimensions for element-wise multiplication." << std::endl;
        return std::vector<std::vector<T>>();
    }

    // Create a result matrix with the same dimensions as the input matrices
    std::vector<std::vector<T>> result(matrix1.size(), std::vector<T>(matrix1[0].size(), static_cast<T>(0)));

    
    // Perform element-wise multiplication
    for (size_t i = 0; i < matrix1.size(); ++i) {
        for (size_t j = 0; j < matrix1[0].size(); ++j) {
            result[i][j] = matrix1[i][j] * matrix2[i][j];
            
        }
    }

    return result;
}

// Function to compute element-wise power for vectors of vectors (2D vectors)
std::vector<std::vector<double>> elementwisePower(const std::vector<std::vector<double>>& base,
                                                  const std::vector<std::vector<double>>& exponent) {
    // Check if the vectors have the same size
    if (base.size() != exponent.size() || base.empty() || base[0].size() != exponent[0].size() || exponent.empty()) {
        std::cerr << "Vectors must have the same non-empty size." << std::endl;
        return {};
    }

    // Result vector
    std::vector<std::vector<double>> result(base.size(), std::vector<double>(base[0].size(), 0.0));

    // Perform element-wise power
    for (size_t i = 0; i < base.size(); ++i) {
        for (size_t j = 0; j < base[0].size(); ++j) {
            result[i][j] = std::pow(base[i][j], exponent[i][j]);
        }
    }

    return result;
}

std::vector<std::vector<std::complex<double>>> elementWiseDivideComplex(const std::vector<std::vector<std::complex<double>>>& vec1,
                                                               const std::vector<std::vector<std::complex<double>>>& vec2) {
    // Assuming vec1 and vec2 have the same dimensions

    std::vector<std::vector<std::complex<double>>> result;

    for (size_t i = 0; i < vec1.size(); ++i) {
        std::vector<std::complex<double>> rowResult;

        for (size_t j = 0; j < vec1[i].size(); ++j) {
            // Perform element-wise division
            std::complex<double> divisionResult = vec1[i][j] / vec2[i][j];
            rowResult.push_back(divisionResult);
        }

        result.push_back(rowResult);
    }

    return result;
}

std::vector<std::vector<std::complex<double>>> elementWiseDivideComplexDouble(const std::vector<std::vector<std::complex<double>>>& vec1,
                                                               const std::vector<std::vector<double>>& vec2) {
    // Assuming vec1 and vec2 have the same dimensions
    
    if( vec1.size() != vec2.size() || vec1[0].size() != vec2[0].size()){
    	printf("ERROR at elementWiseDivideComplexDouble\n");	
    	printf("vec1.size() = %d vec2.size() = %d \n vec1[0].size() = %d vec2[0].size() = %d\n", vec1.size(), vec2.size(), vec1[0].size(), vec1[0].size());
    }

    std::vector<std::vector<std::complex<double>>> result;

    for (size_t i = 0; i < vec1.size(); ++i) {
        std::vector<std::complex<double>> rowResult;

        for (size_t j = 0; j < vec1[i].size(); ++j) {
            // Perform element-wise division
            std::complex<double> divisionResult = vec1[i][j] / vec2[i][j];
            rowResult.push_back(divisionResult);
        }

        result.push_back(rowResult);
    }

    return result;
}

// Function to perform element-wise division of a matrix by a scalar
template <typename T>
std::vector<std::vector<T>> elementWiseDivide(const std::vector<std::vector<T>>& matrix, T divisor) {
    // Create a result matrix with the same dimensions as the input matrix
    std::vector<std::vector<T>> result(matrix.size(), std::vector<T>(matrix[0].size(), static_cast<T>(0)));

    // Perform element-wise division
    for (size_t i = 0; i < matrix.size(); ++i) {
        for (size_t j = 0; j < matrix[0].size(); ++j) {
            result[i][j] = matrix[i][j] / divisor;
        }
    }

    return result;
}

std::vector<std::vector<std::complex<double>>> computeAbsoluteValue(const std::vector<std::vector<std::complex<double>>>& input) {
    std::vector<std::vector<std::complex<double>>> result;

    for (const auto& row : input) {
        std::vector<std::complex<double>> rowResult;
        for (const auto& complexNumber : row) {
            // Compute the absolute value of the complex number
            std::complex<double> absValue = std::abs(complexNumber);
            rowResult.push_back(absValue);
        }
        result.push_back(rowResult);
    }
    return result;
}


std::vector<std::vector<std::complex<double>>> transposeComplex(const std::vector<std::vector<std::complex<double>>>& matrix) {
    // Get the dimensions of the original matrix
    size_t rows = matrix.size();
    size_t cols = matrix[0].size() ;
   
    // Create a matrix with swapped dimensions for the result
    std::vector<std::vector<std::complex<double>>> result(cols, std::vector<std::complex<double>>(rows));

    // Perform the transpose
    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            result[j][i] = matrix[i][j];
        }
    }

    return result;
}


// Function to perform circular shift on a vector
template<typename T>
void circularShift(std::vector<T>& vec, int shift) {
    std::rotate(vec.begin(), vec.begin() + shift, vec.end());
}


// Function to perform fftshift on a 2D complex matrix
void fftshift(std::vector<std::vector<std::complex<double>>>& matrix) {
    const size_t numRows = matrix.size();
    const size_t numCols = matrix[0].size();

    // Calculate the shift amounts for rows and columns
    int shiftRows = numRows / 2;
    int shiftCols = numCols / 2;

    // Apply circular shift to rows
    for (auto& row : matrix) {
        circularShift(row, shiftCols);
    }

    // Apply circular shift to columns
    for (size_t j = 0; j < numCols; ++j) {
        std::vector<std::complex<double>> column;
        column.reserve(numRows);
        for (size_t i = 0; i < numRows; ++i) {
            column.push_back(matrix[i][j]);
        }
        circularShift(column, shiftRows);
        for (size_t i = 0; i < numRows; ++i) {
            matrix[i][j] = column[i];
        }
    }
}


// Perform 2D FFT using FFTW3
void fft(std::vector<double>& data) {
    int N = data.size();
    fftw_complex* in = reinterpret_cast<fftw_complex*>(&data[0]);

    fftw_plan plan = fftw_plan_dft_1d(N, in, in, FFTW_FORWARD, FFTW_ESTIMATE);
    fftw_execute(plan);
    fftw_destroy_plan(plan);
}

void ifft(std::vector<double>& data) {
    int N = data.size();
    fftw_complex* in = reinterpret_cast<fftw_complex*>(&data[0]);

    fftw_plan plan = fftw_plan_dft_1d(N, in, in, FFTW_BACKWARD, FFTW_ESTIMATE);
    fftw_execute(plan);
    fftw_destroy_plan(plan);

    // Normalize the result
    for (int i = 0; i < N; ++i) {
        data[i] /= N;
    }
}



std::vector<std::vector<std::complex<double>>> fft2(std::vector<std::vector<std::complex<double>>>& x, int mrows = 0, int ncols = 0) {
    int numRows = static_cast<int>(x.size());
    int numCols = static_cast<int>(x[0].size());

    // Check if custom size is specified
    if (mrows == 0 || ncols == 0) {
        mrows = numRows;
        ncols = numCols;
    }

    // Create an input array and copy data
    fftw_complex* in = fftw_alloc_complex(numRows * numCols);
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < numCols; ++j) {
            in[i * numCols + j][0] = x[i][j].real();
            in[i * numCols + j][1] = x[i][j].imag();
        }
    }

    // Create an output array
    fftw_complex* out = fftw_alloc_complex(mrows * ncols);

    // Create a plan for 2D FFT
    fftw_plan plan = fftw_plan_dft_2d(mrows, ncols, in, out, FFTW_FORWARD, FFTW_ESTIMATE);

    // Execute the plan
    fftw_execute(plan);

    // Copy the result to a 2D vector
    std::vector<std::vector<std::complex<double>>> result(mrows, std::vector<std::complex<double>>(ncols));
    for (int i = 0; i < mrows; ++i) {
        for (int j = 0; j < ncols; ++j) {
            result[i][j] = { static_cast<float>(out[i * ncols + j][0]), static_cast<float>(out[i * ncols + j][1]) };
        }
    }

    // Clean up
    fftw_destroy_plan(plan);
    fftw_free(in);
    fftw_free(out);

    return result;
}


std::vector<std::vector<std::complex<double>>> ifft2(std::vector<std::vector<std::complex<double>>>& x, int mrows = 0, int ncols = 0) {
    int numRows = static_cast<int>(x.size());
    int numCols = static_cast<int>(x[0].size());

    // Check if custom size is specified
    if (mrows == 0 || ncols == 0) {
        mrows = numRows;
        ncols = numCols;
    }

    // Create an input array and copy data
    fftw_complex* in = fftw_alloc_complex(numRows * numCols);
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < numCols; ++j) {
            in[i * numCols + j][0] = x[i][j].real();
            in[i * numCols + j][1] = x[i][j].imag();
        }
    }

    // Create an output array
    fftw_complex* out = fftw_alloc_complex(mrows * ncols);

    // Create a plan for 2D IFFT
    fftw_plan plan = fftw_plan_dft_2d(mrows, ncols, in, out, FFTW_BACKWARD, FFTW_ESTIMATE);

    // Execute the plan
    fftw_execute(plan);

    // Copy the result to a 2D vector
    std::vector<std::vector<std::complex<double>>> result(mrows, std::vector<std::complex<double>>(ncols));
    for (int i = 0; i < mrows; ++i) {
        for (int j = 0; j < ncols; ++j) {
        	result[i][j] = { out[i * ncols + j][0] / (mrows * ncols), out[i * ncols + j][1] / (mrows * ncols)};
        	//result[i][j] = std::abs(result[i][j]);
        	
        /*
        	if( out[i * ncols + j][0] < 0 ){
        		if(out[i * ncols + j][1] < 0 ){
        			
        			result[i][j] = { static_cast<float>(-1.0 *out[i * ncols + j][0]) / (mrows * ncols), static_cast<float>(-1.0 * out[i * ncols + j][1]) / (mrows * ncols) };
        		}else{
        			result[i][j] = { static_cast<float>(-1.0 * out[i * ncols + j][0]) / (mrows * ncols), static_cast<float> (out[i * ncols + j][1]) / (mrows * ncols) };
        		
        		}
        	} else if(out[i * ncols + j][1] < 0 ){
            		result[i][j] = { static_cast<float>(out[i * ncols + j][0]) / (mrows * ncols), static_cast<float>(-1.0 * out[i * ncols + j][1]) / (mrows * ncols) };
            	}else{
            		result[i][j] = { static_cast<float>(out[i * ncols + j][0])/ (mrows * ncols), static_cast<float>(out[i * ncols + j][1]) / (mrows * ncols) };
            	}
            	*/
            
        }
    }

    // Clean up
    fftw_destroy_plan(plan);
    fftw_free(in);
    fftw_free(out);

    return result;
}


std::vector<std::vector<double>> calculatePhaseAngles(const std::vector<std::vector<std::complex<double>>>& complexVector) {
    

    size_t numRows = complexVector.size();
    size_t numCols = complexVector[0].size();
    
    std::vector<std::vector<double>> phaseAngles(numRows, std::vector<double>(numCols , 0.0));


    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            phaseAngles[i][j] = std::arg(complexVector[i][j]);           
        }
    }

    return phaseAngles;
}

double customMod(double a, double m) {
    // Check if m is zero to follow the convention
    if (m == 0) {
        return a;
    }

    // Compute the remainder after division of a by m
    double result = a - m * std::floor(a / m);
    
    return result;
}

// Function to compute delta based on pyrRef and pyrCurrent for a specific frameIDX
void computeDeltaForFrame(const std::vector<std::vector<double>>& pyrRefAngle,
                           const std::vector<std::vector<double>>& pyrCurrent,
                           std::vector<std::vector<std::vector<double>>>& delta,
                           int frameIDX) {
    // Assuming pyrRefAngle, pyrCurrent, and delta have the same dimensions

    size_t numRows = delta[0].size();
    size_t numCols = delta[0][0].size();
    
   
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            // Compute delta for each element 3.1416 
            delta[frameIDX][i][j] = static_cast<float>(customMod((3.1416+ pyrCurrent[i][j] - pyrRefAngle[i][j]), (3.1416*2) ) - 3.1416);
        }
    }
}


void differenceOfIIR(std::vector<std::vector<std::vector<double>>>& delta, double rl, double rh) {
   

    std::vector<std::vector<double>> lowpass1(delta[0].size(), std::vector<double>(delta[0][0].size()));
    std::vector<std::vector<double>> lowpass2(delta[0].size(), std::vector<double>(delta[0][0].size()));

    for (size_t i = 0; i < delta[0].size(); ++i) {
        for (size_t k = 0; k < delta[0][0].size(); ++k) {
            lowpass1[i][k] = delta[0][i][k];
            lowpass2[i][k] = lowpass1[i][k];
            delta[0][i][k] = 0.0;
        }
    }


    for (size_t i = 0; i < delta[0][0].size(); ++i) {
        for (size_t j = 0; j < delta.size(); ++j) { 
            for (size_t k = 0; k < delta[j].size(); ++k) {
                lowpass1[k][i] = (1.0 - rh) * lowpass1[k][i] + rh * delta[j][k][i];
                lowpass2[k][i] = (1.0 - rl) * lowpass2[k][i] + rl * delta[j][k][i];
                delta[j][k][i] = lowpass1[k][i] - lowpass2[k][i];
   
            }
        }
    }
}

    
    // Butterworth filter function
std::pair<std::vector<double>, std::vector<double>> butter(int order, double cutoff, const std::string& type) {
    double wc = std::tan(cutoff * 3.1416);
    std::vector<double> a(order + 1, 0.0);
    std::vector<double> b(order + 1, 0.0);

    if (type == "low") {
        for (int k = 0; k <= order; ++k) {
            b[k] = std::tgamma(order + 1) / (std::tgamma(k + 1) * std::tgamma(order - k + 1)) * std::pow(wc, order - k);
            a[k] = std::tgamma(order + 1) / (std::tgamma(k + 1) * std::tgamma(order - k + 1)) * std::pow(wc, k);
        }
    } else if (type == "high") {
        for (int k = 0; k <= order; ++k) {
            b[k] = std::pow(-1, k) * std::tgamma(order + 1) / (std::tgamma(k + 1) * std::tgamma(order - k + 1)) * std::pow(wc, order - k);
            a[k] = std::tgamma(order + 1) / (std::tgamma(k + 1) * std::tgamma(order - k + 1)) * std::pow(wc, k);
        }
    } else {
        throw std::invalid_argument("Invalid filter type. Use 'low' or 'high'.");
    }

    return std::make_pair(a, b);
}

void differenceOfButterworths(std::vector<std::vector<std::vector<double>>>& delta, double fl, double fh) {


    auto [low_a, low_b] = butter(1, fl, "low");
    auto [high_a, high_b] = butter(1, fh, "low");

    size_t len = delta[0][0].size();

    std::vector<std::vector<std::vector<double>>> lowpass1 = delta;
    std::vector<std::vector<std::vector<double>>> lowpass2 = lowpass1;
    std::vector<std::vector<std::vector<double>>> prev = lowpass1;

    for (size_t i = 1; i < len; ++i) {
        for (size_t j = 0; j < delta.size(); ++j) {
            for (size_t k = 0; k < delta[j].size(); ++k) {
                lowpass1[j][k][i] = (-high_b[1] * lowpass1[j][k][i] + high_a[0] * delta[j][k][i] + high_a[1] * prev[j][k][i]) / high_b[0];
                lowpass2[j][k][i] = (-low_b[1] * lowpass2[j][k][i] + low_a[0] * delta[j][k][i] + low_a[1] * prev[j][k][i]) / low_b[0];
                prev[j][k][i] = delta[j][k][i];
                delta[j][k][i] = lowpass1[j][k][i] - lowpass2[j][k][i];
            }
        }
    }
}


// C++ equivalent of MATLAB meshgrid function for 2-D grid
std::pair<std::vector<std::vector<double>>, std::vector<std::vector<double>>> meshgrid(const std::vector<double>& x, const std::vector<double>& y) {
    std::vector<std::vector<double>> X(y.size(), std::vector<double>(x.size()));
    std::vector<std::vector<double>> Y(y.size(), std::vector<double>(x.size()));

    for (size_t i = 0; i < y.size(); ++i) {
        for (size_t j = 0; j < x.size(); ++j) {
            X[i][j] = x[j]; // Assign x directly
            Y[i][j] = y[i]; // Assign y directly
        }
    }

    return std::make_pair(X, Y);
}

void getPolarGrid(const std::vector<int>& dimension ,std::vector<std::vector<double>>& angle, std::vector<std::vector<double>>& rad) {
    std::vector<int> center{ static_cast<int>(std::ceil((dimension[0] + 0.5) / 2)), static_cast<int>(std::ceil((dimension[1] + 0.5) / 2)) };

    std::vector<double> x(dimension[1]);
    std::vector<double> y(dimension[0]);

    // Correct variable names for center_x and center_y
    int center_x = center[1];
    int center_y = center[0];

    for (int i = 0; i < dimension[1]; ++i) {
        x[i] = (i + 1 - center_x) / (static_cast<double>(dimension[1]) / 2.0); // Correct dimension[1]
    }

    for (int i = 0; i < dimension[0]; ++i) {
        y[i] = (i + 1 - center_y) / (static_cast<double>(dimension[0]) / 2.0); // Correct dimension[0]
    }

    // Call meshgrid function
    auto result = meshgrid(x, y);

    // Convert to polar coordinates
    angle.resize(dimension[0], std::vector<double>(dimension[1], 0.0));
    rad.resize(dimension[0], std::vector<double>(dimension[1], 0.0));

    for (int i = 0; i < dimension[0]; ++i) {
        for (int j = 0; j < dimension[1]; ++j) {
            angle[i][j] = std::atan2(result.second[i][j], result.first[i][j]); // Use result instead of result2D
            rad[i][j] = std::sqrt(result.first[i][j] * result.first[i][j] + result.second[i][j] * result.second[i][j]); // Use result instead of result2D

        }
    }

    rad[center_y][center_x] = rad[center_y][center_x - 1];
} 


// C++ equivalent of MATLAB clip function
std::vector<std::vector<double>> clip(const std::vector<std::vector<double>>& im, double minValOrRange, double maxVal) {
    // Initialize minVal and maxVal based on input
    double minVal, range;
    if (minValOrRange == 0.0 && maxVal == 0.0) {
        minVal = 0.0;
        maxVal = 1.0;
    } else if (maxVal == 0.0) {
        minVal = minValOrRange;
        maxVal = minVal + 1.0;
    } else {
        minVal = minValOrRange;
    }

    // Check if maxVal is less than minVal
    if (maxVal < minVal) {
        // Handle the error as needed, e.g., throw an exception
        // You can customize this part based on your error handling strategy
        throw std::invalid_argument("MAXVAL should be less than MINVAL");
    }

    // Create a copy of the input matrix to store the result
    std::vector<std::vector<double>> res = im;

    // Apply clipping
    for (size_t i = 0; i < im.size(); ++i) {
        for (size_t j = 0; j < im[0].size(); ++j) {
            if (im[i][j] < minVal) {
                res[i][j] = minVal;
            } else if (im[i][j] > maxVal) {
                res[i][j] = maxVal;
            }
        }
    }

    return res;
}

// Function to get radial mask pair
void getRadialMaskPair(double r, const std::vector<std::vector<double>>& rad, double tWidth ,std::vector<std::vector<double>>& himask , std::vector<std::vector<double>>& lomask ) {
    // Calculate log_rad
    
    std::vector<std::vector<double>> logRad(rad.size(), std::vector<double>(rad[0].size(), 0.0));
    
    for (size_t i = 0; i < rad.size(); ++i) {
        for (size_t j = 0; j < rad[0].size(); ++j) {
            logRad[i][j] = std::log2(rad[i][j]) - std::log2(r);
        }
    }

    
    std::vector<std::vector<double>> temp = clip(logRad, -tWidth, 0.0);

    for (size_t i = 0; i < rad.size(); ++i) {
        for (size_t j = 0; j < rad[0].size(); ++j) {       
            himask[i][j] = temp[i][j] * 3.1416 / (2 * tWidth);
            himask[i][j] = std::abs(std::cos(temp[i][j]));
        }
    }

    
    
    for (size_t i = 0; i < rad.size(); ++i) {
        for (size_t j = 0; j < rad[0].size(); ++j) {
            lomask[i][j] = std::sqrt(1.0 - himask[i][j] * himask[i][j]);
        }
    }

    
   }



// Function to get angle mask
std::vector<std::vector<double>> getAngleMask(int b, int orientations, const std::vector<std::vector<double>>& angle) {
    int order = orientations - 1;
    double constValue = std::pow(2.0, 2 * order) * std::pow(std::tgamma(order + 1), 2) / (orientations * std::tgamma(2 * order + 1));

    std::vector<std::vector<double>> anglemask(angle.size(), std::vector<double>(angle[0].size(), 0.0));

    for (size_t i = 0; i < angle.size(); ++i) {
        for (size_t j = 0; j < angle[0].size(); ++j) {
            double adjustedAngle = std::fmod(3.1416 + angle[i][j] - 3.1416 * (b - 1) / orientations, 2 * 3.1416) - 3.1416;
            anglemask[i][j] = 2 * std::sqrt(constValue) * std::pow(std::cos(adjustedAngle), order) * (std::abs(adjustedAngle) < 3.1416 / 2);
        }
    }

    return anglemask;
}

void printFilters(const std::vector<std::vector<std::vector<double>>>& filters) {
    for (size_t layerIdx = 0; layerIdx < filters.size(); ++layerIdx) {
        const auto& layer = filters[layerIdx];
        for (size_t rowIdx = 0; rowIdx < layer.size(); ++rowIdx) {
            const auto& row = layer[rowIdx];
            for (size_t colIdx = 0; colIdx < row.size(); ++colIdx) {
                std::cout << "Layer: " << layerIdx << " Row: " << rowIdx << " Col: " << colIdx << " Value: " << row[colIdx] << std::endl;
            }
            std::cout << std::endl;  // Separate rows with an empty line
        }
        std::cout << std::endl;  // Separate layers with an empty line
    }
}



std::vector<std::vector<std::vector<double>>> getFilters(const std::vector<int>& dimension, const std::vector<double>& rVals, int orientations, double tWidth) {

    std::vector<std::vector<std::vector<double>>> filters;

    std::vector<std::vector<double>> angle;
    std::vector<std::vector<double>> logRad;

   
    getPolarGrid(dimension,angle,logRad);

    std::vector<std::vector<double>> himask(logRad.size(), std::vector<double>(logRad[0].size(), 0.0));
    std::vector<std::vector<double>> lomaskPrev(logRad.size(), std::vector<double>(logRad[0].size(), 0.0));


     // Call getRadialMaskPair function
    getRadialMaskPair(rVals[0], logRad, tWidth, himask, lomaskPrev);
    
    filters.push_back(himask);
  
    std::vector<std::vector<double>> lomask(logRad.size(), std::vector<double>(logRad[0].size(), 0.0));

    for (size_t k = 1; k < rVals.size(); ++k) {
        std::vector<std::vector<double>> himask(logRad.size(), std::vector<double>(logRad[0].size(), 0.0));
        
        // Call your getRadialMaskPair implementation
        //std::tie(himask, lomask) = getRadialMaskPair(rVals[k], logRad, tWidth);
        getRadialMaskPair(rVals[k], logRad, tWidth,himask,lomask);

        std::vector<std::vector<double>> radMask;
        radMask = elementWiseMultiply(himask, lomask);


        for (int j = 0; j < orientations; ++j) {
            std::vector<std::vector<double>> anglemask;
            
            anglemask = getAngleMask(j, orientations, angle);

            
            // Perform element-wise division by 2
    	    std::vector<std::vector<double>> result = elementWiseDivide(anglemask, 2.0);
    	    
    	    std::vector<std::vector<double>> filter = elementWiseMultiply(radMask, result);    
    	          
            filters.push_back(filter);

        }

        lomaskPrev = lomask;
        
    }

    filters.push_back(lomask);
    return filters;
}



std::vector<bool> sumColumns(const std::vector<std::vector<double>>& matrix) {

    size_t rows = matrix.size();
    size_t cols = matrix[0].size();

    std::vector<bool> result(cols, false);

    for (size_t j = 0; j < cols; ++j) {
        for (size_t i = 0; i < rows; ++i) {
            result[j] = result[j] || (matrix[i][j] > 0.0);
        }
    }

    return result;
    
}

std::vector<int> find(const std::vector<bool>& vector) {
    
    std::vector<int> result;

    for (size_t i = 0; i < vector.size(); ++i) {
        if (vector[i]) {
            result.push_back(i);
        }
    }

    return result;
}



std::vector<int> findRange(const std::vector<int>& vector) {
    if (vector.empty()) {
        return {};
    }

     return { *std::min_element(vector.begin(), vector.end()), *std::max_element(vector.begin(), vector.end()) };
}






std::vector<bool> rotateBool(const std::vector<bool>& vector, int times) {
 
    size_t size = vector.size();
    std::vector<bool> result(size, false);

    for (size_t i = 0; i < size; ++i) {
        result[i] = vector[(i + times) % size];
    }

    return result;
}

std::vector<bool> logicalOr(const std::vector<bool>& vector1, const std::vector<bool>& vector2) {

    
    size_t size = std::max(vector1.size(), vector2.size());
    std::vector<bool> result(size, false);

    for (size_t i = 0; i < size; ++i) {
        if (i < vector1.size()) {
            result[i] =result[i] || vector1[i];
        }
        if (i < vector2.size()) {
            result[i] = result[i] || vector2[i];
        }
    }

    return result;
}

std::vector<std::vector<double>> transpose(const std::vector<std::vector<double>>& matrix) {
    
    
    std::vector<std::vector<double>> result(matrix[0].size(), std::vector<double>(matrix.size(),0.0));

    for (size_t i = 0; i < matrix.size(); ++i) {
        for (size_t j = 0; j < matrix[0].size(); ++j) {
            result[j][i] = matrix[i][j];
        }
    }

    return result;
}




std::vector<std::vector<double>> getSubmatrix(const std::vector<std::vector<double>>& filter,
                                           const std::vector<int>& indices1,
                                           const std::vector<int>& indices2) {
    std::vector<std::vector<double>> croppedFilter;
    for (int i : indices1) {
    	//printf("i = %d filters.size() = %d \n", i, static_cast<int>(filter.size()));
        if (i >= 0 && i <= static_cast<int>(filter.size())) {
            std::vector<double> row;
            for (int j : indices2) {
                if (j >= 0 && j <= static_cast<int>(filter[0].size())) {
                    row.push_back(filter[i][j]);
                } else {
                    // Handle column index out of bounds
                    // You can add appropriate error handling or return a default value.
                    std::cerr << "Column index out of bounds!" << std::endl;
                }
            }
            croppedFilter.push_back(row);
        } else {
            // Handle row index out of bounds
            // You can add appropriate error handling or return a default value.
            std::cerr << "Row index out of bounds!" << std::endl;
        }
    }

    return croppedFilter;
}



std::vector<std::vector<int>> getIDXFromFilter(const std::vector<std::vector<double>>& filter) {
    std::vector<std::vector<int>> filtIDX(2);

    // Create aboveZero matrix
    std::vector<std::vector<int>> aboveZero(filter.size(), std::vector<int>(filter[0].size(), 0));

    for (size_t i = 0; i < filter.size(); ++i) {
        for (size_t j = 0; j < filter[0].size(); ++j) {
            aboveZero[i][j] = filter[i][j] > 1e-10 ? 1 : 0;
        }
    }

    // Compute dim1 and dim2
    std::vector<int> dim1(filter.size(), 0);
    std::vector<int> dim2(filter[0].size(), 0);

    for (size_t i = 0; i < filter.size(); ++i) {
        dim1[i] = std::any_of(aboveZero[i].begin(), aboveZero[i].end(), [](int val) { return val == 1; });
    }

    for (size_t j = 0; j < filter[0].size(); ++j) {
        dim2[j] = std::any_of(aboveZero.begin(), aboveZero.end(), [j](const std::vector<int>& row) { return row[j] == 1; });
    }

    // Perform element-wise OR
    for (size_t i = 0; i < dim1.size(); ++i) {
        dim1[i] |= dim1[dim1.size() - 1 - i];
    }

    for (size_t j = 0; j < dim2.size(); ++j) {
        dim2[j] |= dim2[dim2.size() - 1 - j];
    }

    // Compute idx1 and idx2
    std::vector<int> idx1(filter.size());
    std::vector<int> idx2(filter[0].size());

    std::iota(idx1.begin(), idx1.end(), 0);
    std::iota(idx2.begin(), idx2.end(), 0);

    idx1.erase(std::remove_if(idx1.begin(), idx1.end(), [&dim1](int i) { return dim1[i] != 1; }), idx1.end());
    idx2.erase(std::remove_if(idx2.begin(), idx2.end(), [&dim2](int i) { return dim2[i] != 1; }), idx2.end());

    // Populate filtIDX
    filtIDX[0] = idx1;
    filtIDX[1] = idx2;

    return filtIDX;
}


// Function to crop a matrix based on indices
std::vector<std::vector<double>> cropMatrix(const std::vector<std::vector<double>>& matrix,
                                            const std::vector<int>& rowIndices,
                                            const std::vector<int>& colIndices) {
    std::vector<std::vector<double>> croppedMatrix;

    for (size_t i : rowIndices) {
        std::vector<double> row;

        for (size_t j : colIndices) {
            row.push_back(matrix[i][j]);
        }

        croppedMatrix.push_back(row);
    }

    return croppedMatrix;
}


// Function to get the cropped filters and corresponding indices
std::tuple<std::vector<std::vector<std::vector<double>>>, std::vector<std::vector<std::vector<int>>>> getFilterIDX(const std::vector<std::vector<std::vector<double>>>& filters) {

    size_t nFilts = filters.size();		
 
    std::vector<std::vector<std::vector<int>>> filtIDX;
    filtIDX.resize(nFilts, std::vector<std::vector<int>>(2));
    std::vector<std::vector<std::vector<double>>> croppedFilters(nFilts);

    for (size_t k = 0; k < nFilts; ++k) {
         
         std::vector<std::vector<int>> indices = getIDXFromFilter(filters[k]);
         
         // Print the vector with info
    	 //print2DVectorWithInfo(indices);

        // Assign to filtIDX
        filtIDX[k][0] = indices[0];
        filtIDX[k][1] = indices[1];
        
            // Call getSubmatrix
        croppedFilters[k] = cropMatrix(filters[k], indices[0], indices[1]);

       
    }
    
    return std::make_tuple(croppedFilters, filtIDX);
}



std::vector<std::vector<std::complex<double>>> buildLevel(const std::vector<std::vector<std::complex<double>>>& im_dft,
                        const std::vector<std::vector<std::vector<double>>>& croppedFilters,
                        const std::vector<std::vector<std::vector<int>>>& filtIDX,
                        int k) {


    size_t height = im_dft.size();
    size_t width = (height > 0) ? im_dft[0].size(): 0;
	
    std::vector<std::vector<std::vector<std::complex<double>>>>  resCropped(croppedFilters.size(), std::vector<std::vector<std::complex<double>>>(height,std::vector<std::complex<double>>(width,{0.0,0.0})));
 
    for (size_t frame = 0; frame < resCropped.size(); ++frame) {
        for (size_t i = 0; i < height; ++i) {
            for (size_t j = 0; j < width; ++j) {
                if (i < croppedFilters[frame].size() && j < croppedFilters[frame][i].size()) {
                    std::complex<double> complexCropped(croppedFilters[frame][i][j], 0.0);
                    resCropped[frame][i][j] = complexCropped;
                }
            }
        }
    }	
    
    
	
    std::vector<std::vector<std::complex<double>>> result(height, std::vector<std::complex<double>>(width));
    result = elementWiseMultiply(resCropped[k],im_dft);

    
    fftshift(result);
    result = ifft2(result);
	     
    return result;
}



std::vector<std::vector<std::complex<double>>> reconLevel(
    std::vector<std::vector<std::complex<double>>>& im_dft,
    const std::vector<std::vector<double>>& croppedFilter) {

    size_t numRows = im_dft.size();
    size_t numCols = im_dft[0].size();
    
   
    

    std::vector<std::vector<std::complex<double>>> result(numRows, std::vector<std::complex<double>>(numCols));
    
    
    std::vector<std::vector<std::complex<double>>> resCropped(numRows, std::vector<std::complex<double>>(numCols,{0.0,0.0}));
 
   
    for (size_t i = 0; i < numRows; ++i) {
       for (size_t j = 0; j < numCols; ++j) {
          if (i < croppedFilter.size() && j < croppedFilter[i].size()) {
             std::complex<double> complexCropped(croppedFilter[i][j], 0.0);
             resCropped[i][j] = complexCropped;
         }
       }
    }
    	
    

    im_dft = fft2(im_dft);
    fftshift(im_dft);
    
    std::complex<double> complexScalarTwo(2.0, 0.0);
    
    std::vector<std::vector<std::complex<double>>> elementWiseTemp(numRows, std::vector<std::complex<double>>(numCols));
    elementWiseTemp = elementWiseMultiply(resCropped, im_dft);
    
    
    
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            
           result[i][j] = complexScalarTwo * elementWiseTemp[i][j];
           
        }
    }
    

    return result;
}


void updateMagnifiedLumaFFT(std::vector<std::vector<std::vector<std::complex<double>>>>& magnifiedLumaFFT,
                             const std::vector<std::vector<std::vector<int>>>& filtIDX,
                             const std::vector<std::vector<std::complex<double>>>& curLevelFrame,
                             int level,
                             int frameIDX) {
                             

     	    if(level >= 0 && level < filtIDX.size()){
	    	for(size_t i = 0; i < filtIDX[level][0].size(); i++){
	    		for(size_t j = 0; j < filtIDX[level][1].size(); j++){
	    		  	magnifiedLumaFFT[frameIDX][filtIDX[level][0][i]][filtIDX[level][1][j]] += curLevelFrame[filtIDX[level][0][i]][filtIDX[level][1][j]]; 	
	    		}
	    	}
	    
	    }
}





void updateMagnifiedLumaFFTLowpassFrame(std::vector<std::vector<std::vector<std::complex<double>>>>& magnifiedLumaFFT,
                             const std::vector<std::vector<std::vector<int>>>& filtIDX,
                             const std::vector<std::vector<std::complex<double>>>& lowpassFrame,
                             int level,
                             int frameIDX) {
                             
	    if(level >= 0 && level < filtIDX.size()){
	    	for(size_t i = 0; i < filtIDX[level][0].size(); i++){
	    		for(size_t j = 0; j < filtIDX[level][1].size(); j++){
	    		  
	    		  	magnifiedLumaFFT[frameIDX][filtIDX[level][0][i]][filtIDX[level][1][j]] += lowpassFrame[filtIDX[level][0][i]][filtIDX[level][1][j]];
	    		  	
	    		}
	    	}
	    
	    }
	    

}


void updateLowpassFrame(std::vector<std::vector<std::complex<double>>>& lowpassFrame,
			const std::vector<std::vector<std::vector<std::complex<double>>>>& vidFFT,
			const std::vector<std::vector<std::vector<int>>>& filtIDX,
			const std::vector<std::vector<double>>& croppedFiltersLastPowOfTwo,
			const int level,
			const int frameIDX){
	  
	     if(level >= 0 && level < filtIDX.size()){
	    	for(size_t i = 0; i < filtIDX[level][0].size(); i++){
	    		for(size_t j = 0; j < filtIDX[level][1].size(); j++){
	    		  
	    		  	// is the same dims with lowpassframe
		                std::complex<double> croppedComplex = std::complex<double>(croppedFiltersLastPowOfTwo[i][j], 0.0); // or the second 0.0?
		                
	    			lowpassFrame[filtIDX[level][0][i]][filtIDX[level][1][j]] = vidFFT[frameIDX][filtIDX[level][0][i]][filtIDX[level][1][j]] * croppedComplex;
	    		}
	    	}
	    
	    }else{
	    	printf("updateLowpassFrame level >> filtIDX.size()\n");
	    }
	    
}

std::vector<std::vector<std::complex<double>>> calculateAbsPlusEps(const std::vector<std::vector<std::complex<double>>>& originalLevel, double eps) {
    size_t height = originalLevel.size();
    size_t width = (height > 0) ? originalLevel[0].size() : 0;

    std::vector<std::vector<std::complex<double>>> result(height, std::vector<std::complex<double>>(width, {0.0,0.0}));

    for (size_t i = 0; i < height; ++i) {
        for (size_t j = 0; j < width; ++j) {
            result[i][j] = std::abs(originalLevel[i][j]) + eps;
        }
    }

    return result;
}


// Function to convert an integer-based image to a double-based image
std::vector<std::vector<std::vector<double>>> im2single2(const std::vector<std::vector<std::vector<uint8_t>>>& intImage) {
    size_t numFrames = intImage.size();
    size_t height = (numFrames > 0) ? intImage[0].size() : 0;
    size_t width = (height > 0) ? intImage[0][0].size() / 3 : 0;

    std::vector<std::vector<std::vector<double>>> doubleImage(numFrames, std::vector<std::vector<double>>(height, std::vector<double>(width * 3, 0.0)));

    for (size_t k = 0; k < numFrames; ++k) {
        for (size_t i = 0; i < height; ++i) {
            for (size_t j = 0; j < width; ++j) {
                // Assuming the image has 3 channels (RGB)
                uint8_t r = intImage[k][i][j * 3];
                uint8_t g = intImage[k][i][j * 3 + 1];
                uint8_t b = intImage[k][i][j * 3 + 2];

                // Convert each pixel to double and store in the output vector
                doubleImage[k][i][j * 3] = static_cast<double>(r) / 255.0;
                doubleImage[k][i][j * 3 + 1] = static_cast<double>(g) / 255.0;
                doubleImage[k][i][j * 3 + 2] = static_cast<double>(b) / 255.0;  
            }
        }
    }

    return doubleImage;
}


// Function to calculate exp(1i * phase) for each element in a matrix
std::vector<std::vector<std::complex<double>>> calculateExp1i(const std::vector<std::vector<double>>& phaseOfFrame) {
    // Ensure the dimensions match
    size_t numRows = phaseOfFrame.size();
    size_t numCols = (numRows > 0) ? phaseOfFrame[0].size() : 0;

    // Resulting matrix
    std::vector<std::vector<std::complex<double>>> result(numRows, std::vector<std::complex<double>>(numCols, {0.0, 0.0}));

    // Perform exp(1i * phase) calculation
    for (size_t i = 0; i < numRows; ++i) {
        for (size_t j = 0; j < numCols; ++j) {
            // Calculate exp(1i * phase[i][j])
            //result[i][j] = std::polar(1.0f, phase[i][j]);
            std::complex<double> phaseOfFrameComplex (0.0, phaseOfFrame[i][j]);
             result[i][j] = std::exp(phaseOfFrameComplex);
        }
    }

    return result;
}


void scalePhaseOfFrame(std::vector<std::vector<double>>& phaseOfFrame, double alpha) {

    for (size_t i = 0; i < phaseOfFrame.size(); ++i) {
        for (size_t j = 0; j < phaseOfFrame[i].size(); ++j) {
            phaseOfFrame[i][j] = phaseOfFrame[i][j] * alpha;
        }
    }
}


struct RGBPixel {
    double r, g, b;
};

RGBPixel rgb2ntscPixel(const RGBPixel& rgb) {
    double y = 0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b;
    double i = 0.595 * rgb.r - 0.274 * rgb.g - 0.321 * rgb.b;
    double q = 0.211 * rgb.r - 0.522 * rgb.g + 0.311 * rgb.b;
    
    y = std::max(0.0, std::min(1.0, y));
    i = std::max(-0.5959, std::min(0.5959, i));
    q = std::max(-0.5229, std::min(0.5229, q));

    return {y, i, q};
}

// Function to convert an image from RGB to NTSC
std::vector<std::vector<std::vector<double>>> rgb2ntsc(const std::vector<std::vector<std::vector<double>>>& vid) {
    size_t numFrames = vid.size();
    size_t height = (numFrames > 0) ? vid[0].size() : 0;
    size_t width = (height > 0) ? vid[0][0].size() / 3 : 0;

    std::vector<std::vector<std::vector<double>>> result(numFrames, std::vector<std::vector<double>>(height, std::vector<double>(width * 3, 0.0)));

   
    for (size_t k = 0; k < numFrames; ++k) {
        for (size_t i = 0; i < height; ++i) {
            for (size_t j = 0; j < width; ++j) {
                // Assuming the image has 3 channels (RGB)
                double r = vid[k][i][j * 3];
                double g = vid[k][i][j * 3 + 1];
                double b = vid[k][i][j * 3 + 2];
               
                RGBPixel rgbPixel = {r, g ,b};
                RGBPixel ntscPixel = rgb2ntscPixel(rgbPixel);

                // Store the result in the output vector
                result[k][i][j * 3] = ntscPixel.r;
                result[k][i][j * 3 + 1] = ntscPixel.g;
                result[k][i][j * 3 + 2] = ntscPixel.b;
               
                
            }
        }
    }

    return result;
}



// Function to convert RGB to complex
std::vector<std::vector<std::vector<std::complex<double>>>> rgbToComplex(const std::vector<std::vector<std::vector<double>>>& rgbFrames) {
    size_t numFrames = rgbFrames.size();
    size_t height = (numFrames > 0) ? rgbFrames[0].size() : 0;
    size_t width = (height > 0) ? rgbFrames[0][0].size() / 3 : 0;

    // Initialize a vector of vectors of vectors of complex numbers
    std::vector<std::vector<std::vector<std::complex<double>>>> complexFrames(numFrames, std::vector<std::vector<std::complex<double>>>(height, std::vector<std::complex<double>>(width, std::complex<double>(0.0f, 0.0f))));

    // Convert each pixel from RGB to complex for each frame
    for (size_t k = 0; k < numFrames; ++k) {
        for (size_t i = 0; i < height; ++i) {
            for (size_t j = 0; j < width; ++j) {
                // Assuming the image has 3 channels (RGB)
                double r = rgbFrames[k][i][j * 3];
                double g = rgbFrames[k][i][j * 3 + 1];
                double b = rgbFrames[k][i][j * 3 + 2];

                // Convert RGB to complex number
                std::complex<double> complexPixel(r, g + b);
                
                // Store the result in the output vector
                complexFrames[k][i][j] = complexPixel;
            }
        }
    }

    return complexFrames;
}



// Function to convert RGB to complex
std::vector<std::vector<std::vector<std::complex<double>>>> YtoComplex(const std::vector<std::vector<std::vector<double>>>& originalFrames) {
    size_t numFrames = originalFrames.size();
    size_t height = (numFrames > 0) ? originalFrames[0].size() : 0;
    size_t width = (height > 0) ? originalFrames[0][0].size() / 3 : 0;

    // Initialize a vector of vectors of vectors of complex numbers
    std::vector<std::vector<std::vector<std::complex<double>>>> complexFrames(numFrames, std::vector<std::vector<std::complex<double>>>(height, std::vector<std::complex<double>>(width, std::complex<double>(0.0, 0.0))));

    // Convert each pixel from RGB to complex for each frame
    for (size_t k = 0; k < numFrames; ++k) {
        for (size_t i = 0; i < height; ++i) {
            for (size_t j = 0; j < width; ++j) {
                // Assuming the image has 3 channels (YIQ)
                double y = originalFrames[k][i][j * 3];


                // Convert Y to complex number
                std::complex<double> complexPixel(y, 0.0);
                
                // Store the result in the output vector
                complexFrames[k][i][j] = complexPixel;
            }
        }
    }

    return complexFrames;
}

// Function to convert a single pixel from NTSC to RGB
RGBPixel ntsc2rgbPixel(const double y, const double i, const double q) {

    double r = y + 0.956f * i + 0.621f * q;
    double g = y - 0.272f * i - 0.647f * q;
    double b = y - 1.106f * i +  1.703f * q;
   
    // Clip values to the valid range [0, 1]
    r = std::max(0.0, std::min(1.0, r));
    g = std::max(0.0, std::min(1.0, g));
    b = std::max(0.0, std::min(1.0, b));
    
    return {r, g, b};
}

// Function to convert an image from NTSC to RGB
std::vector<std::vector<double>> ntsc2rgb(const std::vector<std::vector<double>>& ntscImage) {
    
    //size_t numFrames = ntscImage.size();
    size_t height = ntscImage.size();
    size_t width = (height > 0) ? ntscImage[0].size() / 3 : 0;

    std::vector<std::vector<double>> result(height, std::vector<double>(width * 3, 0.0f));
    

     for (size_t i = 0; i < height; ++i) {
        for (size_t j = 0; j < width; ++j) {
             // Assuming the image has 3 channels (RGB)
             double ntscY = ntscImage[i][j * 3];
             double ntscI = ntscImage[i][j * 3 + 1];
             double ntscq = ntscImage[i][j * 3 + 2];
                

             // Convert each pixel from NTSC to RGB
             // RGBPixel ntscPixel = {ntscY, ntscI, ntscq};
             RGBPixel rgbPixel = ntsc2rgbPixel(ntscY,ntscI,ntscq);

             // Store the result in the output vector
             result[i][j * 3] = rgbPixel.r;
             result[i][j * 3 + 1] = rgbPixel.g;
             result[i][j * 3 + 2] = rgbPixel.b;
        }
     }
 
    return result;
}


// Function to convert image to 8-bit unsigned integers
std::vector<std::vector<uint8_t>> im2uint8(const std::vector<std::vector<double>>& image) {

    size_t height = image.size();
    size_t width = (height > 0) ? image[0].size() / 3 : 0;

    // Create the result vector with uint8_t data type
    std::vector<std::vector<uint8_t>> result(height, std::vector<uint8_t>(width * 3, 0));


    for (size_t i = 0; i < height; ++i) {
        for (size_t j = 0; j < width; ++j) {
             // Assuming the image has 3 channels (RGB)
             double r = image[i][j * 3];
             double g = image[i][j * 3 + 1];
             double b = image[i][j * 3 + 2];

              // Convert each pixel to uint8_t
              result[i][j * 3] = static_cast<uint8_t>(r * 255.0);
              result[i][j * 3 + 1] = static_cast<uint8_t>(g * 255.0);
              result[i][j * 3 + 2] = static_cast<uint8_t>(b * 255.0);
            }
        }
    

    return result;
}

/* Below this section having function for time calculation */




