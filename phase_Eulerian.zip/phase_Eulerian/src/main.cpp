#include <iostream>
#include <string>
#include <fftw3.h>

#include <fstream>
// Profilling file
std::ofstream profilling_file("Profilling_info.txt");



#define type_time std::chrono::high_resolution_clock::time_point
#define type_time_calc std::chrono::duration<double>


#include "phase_eulerian.hpp"


int main(int argc, char **argv)
{
    
    std::string input_filename;
    std::string output_filename;
    
    double alpha;
    double cutoff_freq_low;
    double cutoff_freq_high;
    double sigma;
    bool attenuateOtherFreq;
    std::string pyrType;
    std::string temporalFilter;
    
    input_filename = "/home/nickgian/Desktop/standar_libs/phase_Eulerian/data/small_eye_2s.avi";
    output_filename = "/home/nickgian/Desktop/standar_libs/phase_Eulerian/data/small_eye_2s_phase.avi";
    
    attenuateOtherFreq = true; 
    alpha = 100.0;
    cutoff_freq_low = 1;
    cutoff_freq_high = 3;
    sigma = 0;
    pyrType = "octave";
    temporalFilter = "differenceOfIIR";
    

    type_time startAll = std::chrono::high_resolution_clock::now();
    
    phase_eulerian(input_filename, alpha, cutoff_freq_low, cutoff_freq_high, output_filename, sigma, attenuateOtherFreq, pyrType, temporalFilter);

    type_time endAll = std::chrono::high_resolution_clock::now();
    type_time_calc Allduration = endAll - startAll;
    profilling_file << "All Execution time: " << Allduration.count() << " seconds." << std::endl;

    return 0;
}

