#include <chrono>

#include <math.h>
#include <iostream>
#include <string>
#include <vector>
#include <cstdint>
#include <fstream>
#include <cstdio>

#include "helpers.hpp"




void phase_eulerian(std::string& input_filename,
		    double& alpha,
		    double& cutoff_freq_low,
		    double& cutoff_freq_high,
		    std::string& output_filename,
		    double& sigma,
		    bool& attenuateOtherFreq,
		    std::string& pyrType,
		    std::string& temporalFilter)
{

	const char* filePath = input_filename.c_str();
	std::vector<std::vector<std::vector<uint8_t>>> vid;
    	int width ,height,numberOfFrames,numberOfChannels;
    	double fps;
    	AVPixelFormat pixelFormat;
    	
    	width = 0; height = 0; numberOfFrames  = 0; numberOfChannels = 0;
    	
 	readFramesFromAvi(filePath, vid, width, height, numberOfFrames, numberOfChannels,fps, pixelFormat);
 	
 	numberOfChannels = 3; // YUV
 	
 	if (numberOfFrames == 0) {
		std::cerr << "Error: Unable to determine the number of frames." << std::endl;
    	} 
	
 	
    	printf("Computing spatial filters\n");
    	
    	// Create a matrix of zeros with dimensions height x width
    	std::vector<std::vector<int>> zeros = createZerosMatrix<int>(height, width * 3);
    	
    	// Calculate maxSCFpyrHt
   	 int ht = maxSCFpyrHt(zeros);

    	height--;
    	width--;
    	
    	
    	std::vector<int> size = {height, width};
    	std::vector<double> rVals;
    	std::vector<std::vector<std::vector<double>>> filters; 
    	
    	/* Supporting only Octave , halfOctave */
    	if (pyrType == "octave") {
    		for (int i = 0; i <= ht; ++i) {
    			rVals.push_back(std::pow(2.0, -i));
		}
    		filters = getFilters(size, rVals, 4,1.0);
    		printf("Using octave bandwidth pyramid\n");
    	} else if (pyrType == "halfOctave") {
    		for (int i = 0; i <= ht * 2; ++i) {
		    rVals.push_back(std::pow(2.0, -0.5 * i));
		}
       	filters = getFilters(size, rVals, 8, 0.75);
       	printf("Using half octave bandwidth pyramid\n");
    	} 
    	else {
       	std::cerr << "Invalid Filter Type" << std::endl;
        	
    	}
    	
    	   
    	
    	auto result = getFilterIDX(filters);
       
    	// Access the result
    	std::vector<std::vector<std::vector<double>>> croppedFilters = std::get<0>(result);
    	std::vector<std::vector<std::vector<int>>> filtIDX = std::get<1>(result);
    

    	std::vector<std::vector<std::vector<std::complex<double>>>> magnifiedLumaFFT(numberOfFrames,std::vector<std::vector<std::complex<double>>>(height, std::vector<std::complex<double>>(width,{0.0,0.0})));
        
    	int numLevels = filters.size();
        
        
    	printf("Moving video to Fourier domain\n");
        
       std::vector<std::vector<std::vector<double>>> doubleVid;
    	doubleVid = im2single2(vid);
    	//exportFramesdouble(doubleVid,width, height);
	
	
    	std::vector<std::vector<std::vector<double>>>  originalFrames = rgb2ntsc(doubleVid);
    	//rgb2ntsc(im2single(vid(:,:,:,k)));
	
	
	
    	// Convert RGB images to complex-valued images
    	std::vector<std::vector<std::vector<std::complex<double>>>> tVid = YtoComplex(originalFrames); // originalFramesComplex = originalFrames

    	std::vector<std::vector<std::vector<std::complex<double>>>> vidFFT;
    	for(int i=0; i < numberOfFrames; i++){
    		// Perform 2D FFT on the originalFrame
    		tVid[i] = fft2(tVid[i]);
    		fftshift(tVid[i]);
    		vidFFT.push_back(tVid[i]);
   	 }
    
		
    	 

    	
    	
    	std::vector<std::vector<std::complex<double>>> absPyrRef;
    	std::vector<std::vector<std::complex<double>>> pyrRef;
    	std::vector<std::vector<std::complex<double>>> pyrRefPhaseOrig;
	std::vector<std::vector<double>> pyrRefAngle;
	
	std::vector<std::vector<std::complex<double>>> filterResponse;
	std::vector<std::vector<double>> pyrCurrent;
	std::vector<std::vector<double>> phaseOfFrame;
	std::vector<std::vector<std::complex<double>>> originalLevel;
	std::vector<std::vector<std::complex<double>>> tempOrig;
	
	std::vector<std::vector<std::complex<double>>> expPhaseOfFrame;
	std::vector<std::vector<std::complex<double>>> tempTransformOut;
	std::vector<std::vector<std::complex<double>>> curLevelFrame;
	
	/*-----------------------------------------------------------*/
	/* Init the timers for measurement*/
	
	type_time stime_per_level;
	type_time etime_per_level;
	type_time_calc per_level_duration;
	
	type_time stime_delta;
	type_time etime_delta;
	type_time_calc delta_duration;
	
	type_time stime_filter; // not per frame
	type_time etime_filter; // not per frames
	type_time_calc filter_duration;// not per frames
	// need to add in filters time for perframe (both of them) inside the functions
	
	type_time stime_magnification;
	type_time etime_magnification;
	type_time_calc magnification_duration;
	
	type_time stime_lowpass;
	type_time etime_lowpass;
	type_time_calc lowpass_duration;
	
	type_time stime_finalResults;
	type_time etime_finalResults;
	type_time_calc finalResults_duration;
	/*-----------------------------------------------------------*/
	
	for (int level = 0; level < numLevels; ++level){
		stime_per_level = std::chrono::high_resolution_clock::now();
		
		pyrRef = buildLevel(vidFFT[0],croppedFilters,filtIDX,level);
		absPyrRef = computeAbsoluteValue(pyrRef);

		pyrRefPhaseOrig = elementWiseDivideComplex(pyrRef,absPyrRef);
		
		pyrRefAngle = calculatePhaseAngles(pyrRef);

		std::vector<std::vector<std::vector<double>>> delta(numberOfFrames, std::vector<std::vector<double>>(pyrRefAngle.size(), std::vector<double>(pyrRefAngle[0].size(),0.0)));
		
		
		printf("Processing level %d of %d\n", level, numLevels);
		

	  	/* Compute Delta loop*/
		for(int frameIDX=0; frameIDX < numberOfFrames; frameIDX++){
			stime_delta = std::chrono::high_resolution_clock::now();

			filterResponse = buildLevel(vidFFT[frameIDX],croppedFilters,filtIDX,level);
			
			pyrCurrent = calculatePhaseAngles(filterResponse);
			
    			computeDeltaForFrame(pyrRefAngle, pyrCurrent, delta, frameIDX);
    			
    			etime_delta = std::chrono::high_resolution_clock::now();
    			delta_duration = etime_delta - stime_delta;
   			profilling_file << "Frame "<< frameIDX <<" Compute Delta loop Execution time: " << delta_duration.count() << " seconds." << std::endl;
		}


		
		
		// Temporal Filtering
		printf("Bandpassing phases\n");
		/*  Supporting only differenceOfIIR & differenceOfButterworths filters */
		if(temporalFilter == "differenceOfIIR")
		{
			stime_filter = std::chrono::high_resolution_clock::now();
			
			differenceOfIIR(delta,cutoff_freq_low/500.0,cutoff_freq_high/500.0);
			
			etime_filter = std::chrono::high_resolution_clock::now();
			filter_duration = etime_delta - stime_delta;
   			profilling_file << "Whole differenceOfIIR Execution time: " << filter_duration.count() << " seconds." << std::endl;
		}
		else if(temporalFilter == "differenceOfButterworths")
		{
			stime_filter = std::chrono::high_resolution_clock::now();
			
			differenceOfButterworths(delta,cutoff_freq_low/500.0,cutoff_freq_high/500.0);
			
			etime_filter = std::chrono::high_resolution_clock::now();
			filter_duration = etime_delta - stime_delta;
   			profilling_file << "Whole differenceOfButterworths Execution time: " << filter_duration.count() << " seconds." << std::endl;
		}
		else
		{
			std::cerr << "Error: Unable to determine the filter type." << std::endl;
		}
		
		
		printf("Applying magnification\n");
		
		
		for(int frameIDX =0; frameIDX < numberOfFrames; frameIDX++){
			stime_magnification = std::chrono::high_resolution_clock::now(); 
			
			phaseOfFrame = delta[frameIDX];

			originalLevel = buildLevel(vidFFT[frameIDX],croppedFilters,filtIDX,level);

            	
                	scalePhaseOfFrame(phaseOfFrame,alpha);
          	
                	 
                	
                	if(attenuateOtherFreq){
                		std::vector<std::vector<std::complex<double>>> originalLevelAbs = computeAbsoluteValue(originalLevel);                		
                		tempOrig = elementWiseMultiply(originalLevelAbs,pyrRefPhaseOrig);

                	}else{
                		tempOrig = originalLevel;
                		
                	}
                	
                	
          		// Perform exp(1i * phaseOfFrame) calculation
    			expPhaseOfFrame = calculateExp1i(phaseOfFrame);

			tempTransformOut = elementWiseMultiply(expPhaseOfFrame,tempOrig);
			
			curLevelFrame = reconLevel(tempTransformOut, croppedFilters[level]);

			updateMagnifiedLumaFFT(magnifiedLumaFFT, filtIDX, curLevelFrame, level, frameIDX);
			
			etime_magnification = std::chrono::high_resolution_clock::now();
			magnification_duration = etime_magnification - stime_magnification;
			profilling_file << "Frame "<< frameIDX << " Magnification Execution time: " << magnification_duration.count() << " seconds." << std::endl;

		}
		
		etime_per_level = std::chrono::high_resolution_clock::now();
		// Calculate the duration
   		per_level_duration = etime_per_level - stime_per_level;
   		profilling_file << "Level " << level << " Execution time: " << per_level_duration.count() << " seconds." << std::endl;
	
	}
	

	
	//Add unmolested lowpass residual
	numLevels--;
	
	std::vector<std::vector<double>> croppedFiltersLastTemp= croppedFilters.back();
	
		
	std::vector<std::vector<double>> croppedFiltersLast(vidFFT[0].size(), std::vector<double>(vidFFT[0][0].size(),0.0));
	
	for(int i=0; i < croppedFiltersLast.size(); i++){
		for(int j=0; j<croppedFiltersLast[0].size(); j++){
			if(i < croppedFiltersLastTemp.size() && j < croppedFiltersLastTemp[i].size()){
			
				croppedFiltersLast[i][j] = croppedFiltersLastTemp[i][j];	
			}
		}
	}	

	
	
	std::vector<std::vector<double>> two(croppedFiltersLast.size(),std::vector<double>(croppedFiltersLast[0].size(),2.0));
	
	
	std::vector<std::vector<double>> croppedFiltersLastPowOfTwo = elementwisePower(croppedFiltersLast,two);
	
	std::vector<std::vector<std::complex<double>>> lowpassFrame (croppedFiltersLast.size(), std::vector<std::complex<double>>(croppedFiltersLast[0].size(),0.0));
	

	for(int frameIDX = 0; frameIDX < numberOfFrames; frameIDX++){
		stime_lowpass = std::chrono::high_resolution_clock::now();
		
		updateLowpassFrame(lowpassFrame,vidFFT,filtIDX,croppedFiltersLastPowOfTwo,numLevels,frameIDX);
		updateMagnifiedLumaFFTLowpassFrame(magnifiedLumaFFT, filtIDX, lowpassFrame, numLevels, frameIDX);
		
		etime_lowpass = std::chrono::high_resolution_clock::now();
		lowpass_duration = etime_lowpass - stime_lowpass;
		profilling_file << "Frame " << frameIDX << " lowpass Execution time: " << lowpass_duration.count() << " seconds." << std::endl;
		
	}
	
	
	
	std::vector<std::vector<std::vector<uint8_t>>> res;
	
	std::vector<std::vector<double>> outFrame(height, std::vector<double>(width * 3));
		

       	
	for(int k = 0; k < numberOfFrames; k++){
		stime_finalResults = std::chrono::high_resolution_clock::now();
		
    		fftshift(magnifiedLumaFFT[k]);
    		magnifiedLumaFFT[k] = ifft2(magnifiedLumaFFT[k]);

		
		for (size_t i = 0; i < height; ++i) {
            		for (size_t j = 0; j < width; ++j) {
            			outFrame[i][j * 3] = std::abs(magnifiedLumaFFT[k][i][j]); //channel 0
                		outFrame[i][j * 3 + 1] = originalFrames[k][i][j * 3 + 1]; // channel 1
                		outFrame[i][j * 3 + 2] = originalFrames[k][i][j * 3 + 2]; // channel 2
            		}
       	 } /* outFrame(:,:,1) = magnifiedLuma;
       	      outFrame(:,:,2:3) = originalFrame(:,:,2:3); 
       	   */
       	 outFrame = ntsc2rgb(outFrame); // per Frame
    		 
       	 // Put frame in output
       	 res.push_back(im2uint8(outFrame));
       	 
 		 etime_finalResults = std::chrono::high_resolution_clock::now();
 		 finalResults_duration = etime_finalResults - stime_finalResults;
    		 profilling_file << "Frame " << k << " FinalResults Execution time: " << finalResults_duration.count() << " seconds." << std::endl;
       	 
	}
	
	
	exportFrames(res, width, height);

	
	//write video
	const char* framePath = "./data/pics/";
    	

    	// Run the FFmpeg command
    	int flag = runFFmpegCommand(framePath, output_filename);

    	// Check the result of the system command
    	if (flag == 0) {
       	 printf("executed successfully\n");
    	} else {
        	std::cerr << "Error: Unable to write  the video." << std::endl;
    	}
	
}




