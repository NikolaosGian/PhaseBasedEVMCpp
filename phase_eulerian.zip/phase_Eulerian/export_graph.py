import re
import matplotlib.pyplot as plt

def read_execution_times(filename):
    frame_times = {}
    current_frame = None

    with open(filename, 'r') as file:
        for line in file:
            if "Frame" in line and "Execution time" in line:
                match = re.search(r'Frame (\d+) (.+) Execution time: (\d+\.\d+) seconds.', line)
                if match:
                    frame_num = int(match.group(1))
                    operation = match.group(2).strip()
                    execution_time = float(match.group(3))

                    if frame_num not in frame_times:
                        frame_times[frame_num] = {}

                    if operation not in frame_times[frame_num]:
                        frame_times[frame_num][operation] = []

                    frame_times[frame_num][operation].append(execution_time)
                    current_frame = frame_num

            elif "All Execution time" in line:
            	'''
                match = re.search(r'All Execution time: (\d+\.\d+) seconds.', line)
                if match:
                    all_execution_time = float(match.group(1))
                    if "All" not in frame_times:
                        frame_times["All"] = {}
                    frame_times["All"]["All"] = all_execution_time
                 '''


    return frame_times

def calculate_mean_execution_times(frame_times):
    mean_times_per_frame = {}

    for frame_num, operations in frame_times.items():
        mean_times_per_frame[frame_num] = {}
        for operation, times in operations.items():
            mean_times_per_frame[frame_num][operation] = sum(times) / len(times) if isinstance(times, list) and len(times) > 0 else 0

    return mean_times_per_frame

def plot_mean_graph(mean_times_per_frame, operation, output_path):
    plt.plot(list(mean_times_per_frame.keys()), [times.get(operation, 0) for times in mean_times_per_frame.values()], marker='o')
    plt.title(f'Mean Execution Time for {operation} per Frame')
    plt.xlabel('Frame Number')
    plt.ylabel('Mean Execution Time (seconds)')
    plt.savefig(output_path)
    plt.close()

if __name__ == "__main__":
    filename = "Profilling_info.txt"  # Replace with the actual path to your file
    frame_times = read_execution_times(filename)
    mean_times_per_frame = calculate_mean_execution_times(frame_times)

    operations_to_plot = ["Compute Delta loop", "Magnification", "differenceOfIIR" , "differenceOfIIR" ,"lowpass", "FinalResults"]
    
    for operation in operations_to_plot:
        output_path = f"{operation}_mean_plot.png"
        plot_mean_graph(mean_times_per_frame, operation, output_path)

