gprof ./bin/phase_Eulerian gmon.out > gprof/analysis.txt
/home/nickgian/.local/bin/gprof2dot -f prof -o gprof/call_graph.dot gprof/analysis.txt
dot -Tpng gprof/call_graph.dot -o gprof/call_graph.png

